module com.example.osztalyzat_koveto {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.example.osztalyzat_koveto to javafx.fxml;
    exports com.example.osztalyzat_koveto;
}