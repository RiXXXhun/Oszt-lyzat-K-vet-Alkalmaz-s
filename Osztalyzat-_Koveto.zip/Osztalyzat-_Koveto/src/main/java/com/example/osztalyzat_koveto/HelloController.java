package com.example.osztalyzat_koveto;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;

public class HelloController {

    @FXML
    private StackPane menuPane;

    @FXML
    private Pane tanulmanyPane, jegyPane, fajlPane;

    @FXML
    private TableView<Tanulmany> tanulmanyTable;

    @FXML
    private TableColumn<Tanulmany, String> tantargyCol, jegyCol, idopontCol, temakorCol;

    @FXML
    private TextField tantargyField, filenameField;

    @FXML
    private Label avgLabel, msgLabel,msg2Label;

    @FXML
    private ChoiceBox<String> valasztoChoiceBox ;

    String [] tantargy = {"Matematika", "Magyar nyelv" , "Irodalom", "Német nyelv", "Angol nyelv", "Történelem", "Testnevelés",
            "Állampolgári ismeretek", "Asztali alkalmazások fejlesztése", "Szakmai angol", "Webprogramozás", "IKT projektmunka", "Szoftvertesztelés"};

    @FXML
    private ChoiceBox<Integer> jegyChoiceBox;

    Integer [] jegyek = {1, 2, 3, 4, 5};

    @FXML
    private DatePicker dateDatePicker;

}