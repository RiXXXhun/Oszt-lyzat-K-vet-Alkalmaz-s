package com.example.osztalyzat_koveto;

public class Tanulmany {

    private String tantargy;

    private int jegy;

    private Boolean date;

    private String temakor;


    public Tanulmany() {
    }
    public Tanulmany(String tantargy, int jegy, Boolean date, String temakor) {
        this.tantargy = tantargy;
        this.jegy = jegy;
        this.date = date;
        this.temakor = temakor;
    }

    public String getTantargy() {
        return tantargy;
    }

    public void setTantargy(String tantargy) {
        this.tantargy = tantargy;
    }

    public int getJegy() {
        return jegy;
    }

    public void setJegy(int jegy) {
        this.jegy = jegy;
    }

    public Boolean getDate() {
        return date;
    }

    public void setDate(Boolean date) {
        this.date = date;
    }

    public String getTemakor() {
        return temakor;
    }

    public void setTemakor(String temakor) {
        this.temakor = temakor;
    }
}
