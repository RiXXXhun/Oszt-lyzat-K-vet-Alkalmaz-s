module com.example.osztalyzatkoveto {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.osztalyzatkoveto to javafx.fxml;
    exports com.example.osztalyzatkoveto;
}